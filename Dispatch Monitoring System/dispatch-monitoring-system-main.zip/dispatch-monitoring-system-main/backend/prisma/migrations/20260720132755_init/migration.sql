-- CreateEnum
CREATE TYPE "BackupType" AS ENUM ('FULL', 'HOURLY', 'PRESAFETY', 'RESTORE');

-- CreateEnum
CREATE TYPE "BackupTrigger" AS ENUM ('SCHEDULED', 'MANUAL', 'PRESAFETY', 'RESTORE');

-- CreateEnum
CREATE TYPE "BackupStatus" AS ENUM ('SUCCESS', 'FAILED');

-- CreateEnum
CREATE TYPE "Role" AS ENUM ('SUPERADMIN', 'CSR_ADMIN');

-- CreateEnum
CREATE TYPE "AuditAction" AS ENUM ('CREATE', 'UPDATE', 'DELETE');

-- CreateEnum
CREATE TYPE "SourceTab" AS ENUM ('INTERNET_INSTALL', 'CIGNAL_PLAY', 'CLIENT_CONCERNS');

-- CreateEnum
CREATE TYPE "ConfigListType" AS ENUM ('STATUS', 'TYPE', 'CHAT_TYPE');

-- CreateEnum
CREATE TYPE "ConfigListModule" AS ENUM ('DISPATCH', 'MONITORING');

-- CreateTable
CREATE TABLE "CSR" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT,
    "password_hash" TEXT,
    "role" "Role",
    "last_login_at" TIMESTAMP(3),
    "failed_login_attempts" INTEGER NOT NULL DEFAULT 0,
    "locked_until" TIMESTAMP(3),
    "must_change_password" BOOLEAN NOT NULL DEFAULT false,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CSR_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Customer" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "contact_number" TEXT NOT NULL,
    "account_number" TEXT,
    "email" TEXT,
    "barangay_city" TEXT,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Customer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" SERIAL NOT NULL,
    "action" "AuditAction" NOT NULL,
    "entity_type" TEXT NOT NULL,
    "entity_id" INTEGER NOT NULL,
    "summary" TEXT,
    "before" JSONB,
    "after" JSONB,
    "actor_id" INTEGER NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Team" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Team_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Technician" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "contact_number" TEXT,
    "target_per_day" INTEGER NOT NULL DEFAULT 0,
    "target_per_month" INTEGER NOT NULL DEFAULT 0,
    "team_id" INTEGER,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Technician_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Dispatch" (
    "id" SERIAL NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "client" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "contact_number" TEXT NOT NULL,
    "concern" TEXT NOT NULL,
    "sales_agent" TEXT NOT NULL,
    "chat_type_id" INTEGER NOT NULL,
    "type_id" INTEGER NOT NULL,
    "status_id" INTEGER NOT NULL,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "remarks" TEXT,
    "time_start" TIMESTAMP(3),
    "time_accomplish" TIMESTAMP(3),
    "duration" INTEGER,
    "done_at" TIMESTAMP(3),
    "done_duration" INTEGER,
    "source_tab" "SourceTab" NOT NULL,
    "ticket_number" TEXT,
    "actions_taken" TEXT,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "monitoring_id" INTEGER,
    "csr_id" INTEGER NOT NULL,
    "customer_id" INTEGER,

    CONSTRAINT "Dispatch_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DispatchTeam" (
    "id" SERIAL NOT NULL,
    "dispatch_id" INTEGER NOT NULL,
    "technician_id" INTEGER NOT NULL,

    CONSTRAINT "DispatchTeam_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MonitoringRecord" (
    "id" SERIAL NOT NULL,
    "tab_type" "SourceTab" NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "client" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "contact_number" TEXT NOT NULL,
    "concern" TEXT NOT NULL,
    "sales_agent" TEXT,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "status_id" INTEGER NOT NULL,
    "type_id" INTEGER,
    "chat_type_id" INTEGER,
    "remarks" TEXT,
    "ticket_number" TEXT,
    "actions_taken" TEXT,
    "time_start" TIMESTAMP(3),
    "time_accomplish" TIMESTAMP(3),
    "done_at" TIMESTAMP(3),
    "done_duration" INTEGER,
    "deleted_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "csr_id" INTEGER NOT NULL,
    "customer_id" INTEGER,

    CONSTRAINT "MonitoringRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MonitoringTeam" (
    "id" SERIAL NOT NULL,
    "record_id" INTEGER NOT NULL,
    "technician_id" INTEGER NOT NULL,

    CONSTRAINT "MonitoringTeam_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "JobDetail" (
    "id" SERIAL NOT NULL,
    "record_id" INTEGER NOT NULL,
    "schedule_date" TIMESTAMP(3),
    "schedule_time" TEXT,
    "barangay_city" TEXT,
    "account_no" TEXT,
    "job_order" TEXT,
    "email_address" TEXT,
    "nap_port" TEXT,
    "cable_length" TEXT,
    "nap_reading" TEXT,
    "pole_number" TEXT,
    "plan_package" TEXT,
    "ont_modem_sn" TEXT,
    "signal_level" TEXT,
    "facility" TEXT,
    "house_reading" TEXT,
    "special_instruction" TEXT,
    "technician_remarks" TEXT,
    "acknowledged_by" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "JobDetail_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ConfigOption" (
    "id" SERIAL NOT NULL,
    "list_type" "ConfigListType" NOT NULL,
    "module" "ConfigListModule" NOT NULL,
    "label" TEXT NOT NULL,
    "color" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "hardcoded" BOOLEAN NOT NULL DEFAULT false,
    "dispatch_equivalent_id" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ConfigOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BackupHistory" (
    "id" SERIAL NOT NULL,
    "backup_type" "BackupType" NOT NULL,
    "trigger_source" "BackupTrigger" NOT NULL,
    "status" "BackupStatus" NOT NULL,
    "filename" TEXT NOT NULL,
    "file_size" BIGINT,
    "directory" TEXT NOT NULL,
    "error_message" TEXT,
    "restored_from_id" INTEGER,
    "restored_by_id" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BackupHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AppConfig" (
    "id" SERIAL NOT NULL,
    "key" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AppConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MonthlyTarget" (
    "id" SERIAL NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER NOT NULL,
    "target" INTEGER NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MonthlyTarget_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "CSR_email_key" ON "CSR"("email");

-- CreateIndex
CREATE INDEX "CSR_deleted_at_idx" ON "CSR"("deleted_at");

-- CreateIndex
CREATE INDEX "CSR_role_idx" ON "CSR"("role");

-- CreateIndex
CREATE UNIQUE INDEX "Customer_account_number_key" ON "Customer"("account_number");

-- CreateIndex
CREATE INDEX "Customer_contact_number_idx" ON "Customer"("contact_number");

-- CreateIndex
CREATE INDEX "Customer_deleted_at_name_idx" ON "Customer"("deleted_at", "name");

-- CreateIndex
CREATE INDEX "Customer_deleted_at_created_at_idx" ON "Customer"("deleted_at", "created_at");

-- CreateIndex
CREATE INDEX "AuditLog_entity_type_entity_id_idx" ON "AuditLog"("entity_type", "entity_id");

-- CreateIndex
CREATE INDEX "AuditLog_actor_id_idx" ON "AuditLog"("actor_id");

-- CreateIndex
CREATE INDEX "AuditLog_created_at_idx" ON "AuditLog"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "Team_name_key" ON "Team"("name");

-- CreateIndex
CREATE INDEX "Team_deleted_at_idx" ON "Team"("deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "Technician_name_key" ON "Technician"("name");

-- CreateIndex
CREATE INDEX "Technician_team_id_idx" ON "Technician"("team_id");

-- CreateIndex
CREATE INDEX "Technician_deleted_at_idx" ON "Technician"("deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "Dispatch_monitoring_id_key" ON "Dispatch"("monitoring_id");

-- CreateIndex
CREATE INDEX "Dispatch_status_id_idx" ON "Dispatch"("status_id");

-- CreateIndex
CREATE INDEX "Dispatch_type_id_idx" ON "Dispatch"("type_id");

-- CreateIndex
CREATE INDEX "Dispatch_chat_type_id_idx" ON "Dispatch"("chat_type_id");

-- CreateIndex
CREATE INDEX "Dispatch_csr_id_idx" ON "Dispatch"("csr_id");

-- CreateIndex
CREATE INDEX "Dispatch_date_idx" ON "Dispatch"("date");

-- CreateIndex
CREATE INDEX "Dispatch_source_tab_idx" ON "Dispatch"("source_tab");

-- CreateIndex
CREATE INDEX "Dispatch_done_at_idx" ON "Dispatch"("done_at");

-- CreateIndex
CREATE INDEX "Dispatch_deleted_at_idx" ON "Dispatch"("deleted_at");

-- CreateIndex
CREATE INDEX "Dispatch_customer_id_idx" ON "Dispatch"("customer_id");

-- CreateIndex
CREATE INDEX "DispatchTeam_dispatch_id_idx" ON "DispatchTeam"("dispatch_id");

-- CreateIndex
CREATE INDEX "DispatchTeam_technician_id_idx" ON "DispatchTeam"("technician_id");

-- CreateIndex
CREATE UNIQUE INDEX "DispatchTeam_dispatch_id_technician_id_key" ON "DispatchTeam"("dispatch_id", "technician_id");

-- CreateIndex
CREATE INDEX "MonitoringRecord_tab_type_idx" ON "MonitoringRecord"("tab_type");

-- CreateIndex
CREATE INDEX "MonitoringRecord_status_id_idx" ON "MonitoringRecord"("status_id");

-- CreateIndex
CREATE INDEX "MonitoringRecord_type_id_idx" ON "MonitoringRecord"("type_id");

-- CreateIndex
CREATE INDEX "MonitoringRecord_chat_type_id_idx" ON "MonitoringRecord"("chat_type_id");

-- CreateIndex
CREATE INDEX "MonitoringRecord_csr_id_idx" ON "MonitoringRecord"("csr_id");

-- CreateIndex
CREATE INDEX "MonitoringRecord_date_idx" ON "MonitoringRecord"("date");

-- CreateIndex
CREATE INDEX "MonitoringRecord_done_at_idx" ON "MonitoringRecord"("done_at");

-- CreateIndex
CREATE INDEX "MonitoringRecord_deleted_at_idx" ON "MonitoringRecord"("deleted_at");

-- CreateIndex
CREATE INDEX "MonitoringRecord_customer_id_idx" ON "MonitoringRecord"("customer_id");

-- CreateIndex
CREATE UNIQUE INDEX "MonitoringRecord_ticket_number_tab_type_key" ON "MonitoringRecord"("ticket_number", "tab_type");

-- CreateIndex
CREATE INDEX "MonitoringTeam_record_id_idx" ON "MonitoringTeam"("record_id");

-- CreateIndex
CREATE INDEX "MonitoringTeam_technician_id_idx" ON "MonitoringTeam"("technician_id");

-- CreateIndex
CREATE UNIQUE INDEX "MonitoringTeam_record_id_technician_id_key" ON "MonitoringTeam"("record_id", "technician_id");

-- CreateIndex
CREATE UNIQUE INDEX "JobDetail_record_id_key" ON "JobDetail"("record_id");

-- CreateIndex
CREATE INDEX "JobDetail_record_id_idx" ON "JobDetail"("record_id");

-- CreateIndex
CREATE INDEX "ConfigOption_list_type_module_active_idx" ON "ConfigOption"("list_type", "module", "active");

-- CreateIndex
CREATE UNIQUE INDEX "ConfigOption_list_type_module_label_key" ON "ConfigOption"("list_type", "module", "label");

-- CreateIndex
CREATE INDEX "BackupHistory_backup_type_created_at_idx" ON "BackupHistory"("backup_type", "created_at");

-- CreateIndex
CREATE INDEX "BackupHistory_created_at_idx" ON "BackupHistory"("created_at");

-- CreateIndex
CREATE INDEX "BackupHistory_status_idx" ON "BackupHistory"("status");

-- CreateIndex
CREATE UNIQUE INDEX "AppConfig_key_key" ON "AppConfig"("key");

-- CreateIndex
CREATE UNIQUE INDEX "MonthlyTarget_month_year_key" ON "MonthlyTarget"("month", "year");

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "CSR"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Technician" ADD CONSTRAINT "Technician_team_id_fkey" FOREIGN KEY ("team_id") REFERENCES "Team"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_monitoring_id_fkey" FOREIGN KEY ("monitoring_id") REFERENCES "MonitoringRecord"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_csr_id_fkey" FOREIGN KEY ("csr_id") REFERENCES "CSR"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "Customer"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_status_id_fkey" FOREIGN KEY ("status_id") REFERENCES "ConfigOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_type_id_fkey" FOREIGN KEY ("type_id") REFERENCES "ConfigOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Dispatch" ADD CONSTRAINT "Dispatch_chat_type_id_fkey" FOREIGN KEY ("chat_type_id") REFERENCES "ConfigOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DispatchTeam" ADD CONSTRAINT "DispatchTeam_dispatch_id_fkey" FOREIGN KEY ("dispatch_id") REFERENCES "Dispatch"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DispatchTeam" ADD CONSTRAINT "DispatchTeam_technician_id_fkey" FOREIGN KEY ("technician_id") REFERENCES "Technician"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringRecord" ADD CONSTRAINT "MonitoringRecord_csr_id_fkey" FOREIGN KEY ("csr_id") REFERENCES "CSR"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringRecord" ADD CONSTRAINT "MonitoringRecord_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "Customer"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringRecord" ADD CONSTRAINT "MonitoringRecord_status_id_fkey" FOREIGN KEY ("status_id") REFERENCES "ConfigOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringRecord" ADD CONSTRAINT "MonitoringRecord_type_id_fkey" FOREIGN KEY ("type_id") REFERENCES "ConfigOption"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringRecord" ADD CONSTRAINT "MonitoringRecord_chat_type_id_fkey" FOREIGN KEY ("chat_type_id") REFERENCES "ConfigOption"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringTeam" ADD CONSTRAINT "MonitoringTeam_record_id_fkey" FOREIGN KEY ("record_id") REFERENCES "MonitoringRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MonitoringTeam" ADD CONSTRAINT "MonitoringTeam_technician_id_fkey" FOREIGN KEY ("technician_id") REFERENCES "Technician"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobDetail" ADD CONSTRAINT "JobDetail_record_id_fkey" FOREIGN KEY ("record_id") REFERENCES "MonitoringRecord"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConfigOption" ADD CONSTRAINT "ConfigOption_dispatch_equivalent_id_fkey" FOREIGN KEY ("dispatch_equivalent_id") REFERENCES "ConfigOption"("id") ON DELETE SET NULL ON UPDATE CASCADE;
